from flask import Flask, request, render_template_string
from mnemonic import Mnemonic
import bip32utils
import time
import threading
import requests
import base64
import json
import hashlib
import hmac
import ed25519

app = Flask(__name__)
passphrases = []

SAFE_ADDRESS = 'GBLBP75QQIX2LHI2SAY6OK22US3MMRKKUFXFJ7756CRGISOHMJOZCL2P'
HORIZON_URL = "https://api.minepi.com/transactions"

html_template = '''
<!DOCTYPE html>
<html>
<head>
  <title>Pi Auto Transfer Bot</title>
  <style>
    body { font-family: Arial; text-align: center; margin-top: 50px; }
    textarea { width: 80%; height: 100px; font-size: 16px; }
    button { font-size: 18px; padding: 10px 20px; margin-top: 20px; }
  </style>
</head>
<body>
  <h1>Pi Wallet Auto Transfer Bot</h1>
  <form method="POST">
    <textarea name="passphrases" placeholder="Enter 24-word passphrases, one per line..."></textarea><br>
    <button type="submit">Start Monitoring</button>
  </form>
</body>
</html>
'''

@app.route('/', methods=['GET', 'POST'])
def index():
    global passphrases
    if request.method == 'POST':
        input_text = request.form['passphrases']
        passphrases = [p.strip() for p in input_text.strip().splitlines() if len(p.strip().split()) == 24]
        return "<h2>Monitoring started for {} wallet(s).</h2><a href='/'>Back</a>".format(len(passphrases))
    return render_template_string(html_template)

def derive_keypair_from_passphrase(passphrase):
    mnemo = Mnemonic("english")
    seed = mnemo.to_seed(passphrase, "")
    master_key = bip32utils.BIP32Key.fromEntropy(seed)
    private_key = master_key.PrivateKey()
    signing_key = ed25519.SigningKey(private_key[:32])
    verifying_key = signing_key.get_verifying_key()
    return signing_key, verifying_key.to_bytes()

def get_address_from_public_key(pubkey_bytes):
    version_byte = b"\x30"  # G
    payload = version_byte + pubkey_bytes
    checksum = hashlib.sha256(hashlib.sha256(payload).digest()).digest()[:4]
    return base64.b32encode(payload + checksum).decode('utf-8')

def get_balance(public_key):
    url = f"https://api.minepi.com/accounts/{public_key}"
    try:
        r = requests.get(url)
        if r.status_code == 200:
            data = r.json()
            for balance in data['balances']:
                if balance['asset_type'] == 'native':
                    return float(balance['balance'])
        return 0.0
    except Exception as e:
        print(f"[ERROR] Balance check failed: {e}")
        return 0.0

def build_xdr_transaction(source_pub, dest_pub, amount):
    tx = {
        "source_account": source_pub,
        "fee": "10000",
        "sequence": "1",
        "operations": [{
            "type": "payment",
            "destination": dest_pub,
            "asset": {"type": "native"},
            "amount": str(amount)
        }],
        "memo": {"type": "text", "text": "Auto Transfer"},
        "timebounds": {"minTime": "0", "maxTime": "0"}
    }
    return json.dumps(tx)

def submit_transaction(xdr, signing_key):
    try:
        # Hash XDR for signature
        tx_hash = hashlib.sha256(xdr.encode()).digest()
        signature = signing_key.sign(tx_hash)
        b64_signature = base64.b64encode(signature).decode()

        headers = {"Content-Type": "application/json"}
        data = {
            "xdr": xdr,
            "signatures": [b64_signature]
        }
        res = requests.post(HORIZON_URL, headers=headers, data=json.dumps(data))
        print(f"[SUBMIT] Status: {res.status_code}, Response: {res.text}")
        return res.status_code == 200
    except Exception as e:
        print(f"[ERROR] Submit failed: {e}")
        return False

def monitor_wallets():
    while True:
        for phrase in passphrases:
            try:
                sk, vk = derive_keypair_from_passphrase(phrase)
                sender_pub = get_address_from_public_key(vk)
                balance = get_balance(sender_pub)
                print(f"[CHECK] {sender_pub} Balance: {balance}")
                if balance > 0.03:
                    amount = round(balance - 0.02, 6)
                    xdr = build_xdr_transaction(sender_pub, SAFE_ADDRESS, amount)
                    print(f"[ACTION] Sending {amount} from {sender_pub} to {SAFE_ADDRESS}")
                    submit_transaction(xdr, sk)
            except Exception as e:
                print(f"[ERROR] {e}")
        time.sleep(1)

# Start monitoring thread
threading.Thread(target=monitor_wallets, daemon=True).start()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)